package MathProgram;

public class Ex3 {
	
	public static void main(String[]args) {
		
		double a = 30;
		
		double b= Math.toRadians(a);
		
		//sine value of a
		
		System.out.println("Sine Value of a is:"+Math.sin(a));
		
		//cosine value of a
		
		System.out.println("Cosine value of a is:"+Math.cos(a));
		
		//tan value of a
		
		System.out.println("tan Value of a is:"+Math.tan(a));
		
		
	}

}
